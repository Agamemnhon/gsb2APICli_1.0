import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Posseder } from '../models/posseder';
import { PossederService } from '../services/posseder.service';

@Component({
  selector: 'app-posseder',
  templateUrl: './posseder.component.html'
})
export class PossederComponent implements OnInit {
  public posseder: Posseder;
  public error: string;
  public id_praticien: number;
  public id_specialite: number;
  public title: string;
  constructor(
    private posserderService: PossederService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.title="Modification d'une Spécialité";
    this.posseder = new Posseder();
    this.id_praticien = +this.activatedRoute.snapshot.paramMap.get('id_praticien');
    this.id_specialite = +this.activatedRoute.snapshot.paramMap.get('id_specialite');
    this.getPosseder(this.id_praticien, this.id_specialite);
  }
  getPosseder(id_praticien: number, id_specialite: number){
    this.posserderService.getPosseder(id_praticien, id_specialite).subscribe(
      (posseder: Posseder) => { this.posseder = posseder;},
      (error) => { this.error = error.error.message; }
    );
  }
  cancel(id_praticien:number){
  }

  validatePosseder(id_praticien: number, id_specialite:number){

  }
  specSelected(id_spec: number){
    this.posseder.id_specialite = id_spec;
  }

}
