export class Praticien {
  public id_praticien: number;
  public id_type_praticien: number;
  public code_praticien: number;
  public nom_praticien: String;
  public prenom_praticien: String;
  public adresse_praticien: String;
  public cp_praticien: number;
  public ville_praticien: String;
  public cp_notoriete: number;
}
