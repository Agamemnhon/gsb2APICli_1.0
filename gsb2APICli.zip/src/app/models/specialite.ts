export class Specialite {
  public id_specialite: number;
  public lib_specialite: String;
}
