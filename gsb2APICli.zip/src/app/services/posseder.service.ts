import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SharedService } from './shared.service';

@Injectable({
  providedIn: 'root'
})
export class PossederService {

  private gsbAPI: string = 'http://localhost/gsbNAPI/public/api/';
  private api_token: string = this.sharedService.user.remember_token;
  public headers = new HttpHeaders({ 'Content-Type': 'application/json', 'Authorization': 'Bearer '+ this.api_token});
  constructor(
    private httpClient: HttpClient,
    private sharedService: SharedService
  ) { }

  getPosseder(id_praticien: number, id_specialite:number):Observable<any>{
    return this.httpClient.get(this.gsbAPI+'posseders/'+id_praticien+'/'+id_specialite, {headers: this.headers});
  }
}
